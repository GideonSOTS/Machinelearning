import numpy as np
import os

# Load Data
data = np.loadtxt(os.path.join('Data', 'ex1data1.txt'), delimiter=',')
X, y = data[:, 0], data[:, 1]

m = y.size      # number of training examples 

# Here, a column of ones is added to X. That is, the numpy function stack joins arrays along a given axis. 
# The axis (axis=1) refers to columns (features).
X = np.stack([np.ones(m), X], axis=1)

def computeCost(X, y, theta):           # compute cost for linear regression
 
    m = y.size                          # number of training examples
    J = 0                               # initialize cost value

    predictions = X.dot(theta)          # predictions of hypothesis on all m examples
    print(predictions)
    print('-------------------  ')
    sqrErrors = (predictions - y) ** 2  # squared errors    
    J = 1 / (2 * m) * np.sum(sqrErrors) # compute the cost
   
    return J

J = computeCost(X, y, theta=np.array([0.0, 0.0]))           # compute and display initial cost
print('With theta = [0, 0] \nCost computed = %.2f' % J)
print('Expected cost value (approximately) 32.07\n')

J = computeCost(X, y, theta=np.array([-1, 2]))              # compute and display cost with non-zero theta
print('With theta = [-1, 2]\nCost computed = %.2f' % J)
print('Expected cost value (approximately) 54.24')