import numpy as np
from featureNormalize import featureNormalize
from computeCost import computeCost

# Load Data
data = np.loadtxt('Data/ex1data2.txt', delimiter=',')
X = data[:, 0:2]   # two features: size and number of bedrooms
y = data[:, 2]     # target variable: price
m = y.shape[0]

# Feature Normalization
X, mu, sigma = featureNormalize(X)   # unpacking

# Add a column of ones to X (bias term)
X = np.column_stack([np.ones(m), X])  # shape (47, 3)

# Compute initial cost
theta = np.zeros(X.shape[1])    # initialize fitting parameters (3, )
J = computeCost(X, y, theta)    # compute and display initial cost
print("Theta initialized to zeros:", theta)
print("Computed cost J:", J)

theta = np.array([-1, 2, 0.5])  # example theta
J = computeCost(X, y, theta)    # compute cost with non-zero theta  
print("Theta set to [-1, 2, 0.5]:", theta)
print("Computed cost J with non-zero theta:", J)