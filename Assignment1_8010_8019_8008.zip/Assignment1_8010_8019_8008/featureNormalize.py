import os
import numpy as np


# Load data
data = np.loadtxt(os.path.join('Data', 'ex1data2.txt'), delimiter=',')
X = data[:, :2]
y = data[:, 2]
m = y.size

# print out some data points
print('{:>8s}{:>8s}{:>10s}'.format('X[:,0]', 'X[:, 1]', 'y'))
print('-'*26)
for i in range(10):
    print('{:8.0f}{:8.0f}{:10.0f}'.format(X[i, 0], X[i, 1], y[i]))

def featureNormalize(X):
   
    X_norm = X.copy()
    mu = np.mean(X, axis=0)          # mean of each feature
    sigma = np.std(X, axis=0)        # standard deviation of each feature

    # Normalize each feature
    X_norm = (X - mu) / sigma

    return X_norm, mu, sigma

# call featureNormalize on the loaded data
X_norm, mu, sigma = featureNormalize(X)

print('Computed mean:', mu)
print('Computed standard deviation:', sigma)
print('First 10 examples from the normalized dataset: \n', X_norm[:10])