import os
import numpy as np
from matplotlib import pyplot
from mpl_toolkits.mplot3d import Axes3D  # needed to plot 3-D surfaces
from computeCost import computeCost

# Load Data
data = np.loadtxt(os.path.join('Data', 'ex1data1.txt'), delimiter=',')
X, y = data[:, 0], data[:, 1]

def gradientDescent(X, y, theta, alpha, num_iterations):
   # Initialize some useful values
    m = y.shape[0]  # number of training examples
    
    # make a copy of theta, to avoid changing the original array, since numpy arrays
    # are passed by reference to functions
    theta = theta.copy()

    cost_history = [] # Use a python list to save cost in every iteration

    for i in range(num_iterations):
        # Here, a column of ones is added to X. That is, the numpy function stack joins arrays along a given axis. 
        # The axis (axis=1) refers to columns (features)
        #X = np.stack([np.ones(m), X], axis=1)
        predictions = X.dot(theta)
        errors = predictions - y
        delta = (1 / m) * (X.T.dot(errors))                 # gradient
        theta -= alpha * delta                              # update theta
        cost_history.append(computeCost(X, y, theta))       # save the cost J in every iteration

    return theta, cost_history

m = X.shape[0]
theta = np.zeros(2)                 # initial theta
X = np.column_stack([np.ones(m), X])  # add a column of ones to X
num_iterations = 1500               # number of iterations for gradient descent
alpha = 0.01                        # learning rate

theta, cost_history = gradientDescent(X, y, theta, alpha, num_iterations)
print('Theta found by gradient descent: {:.4f}, {:.4f}'.format(*theta))
print('Expected theta values (approximately): [-3.6303, 1.1664]')

# Plot Data
def plotData(x, y):
   
    fig = pyplot.figure()                                   # open a new figure window
    pyplot.plot(x, y, 'ro', ms=10, mec='k')                 # Plot the data
    pyplot.ylabel('Profit in $10,000')                      # y-axis label
    pyplot.xlabel('Population of City in 10,000s')          # x-axis label  
    
    return fig

#plot the linear fit
plotData(X[:, 1], y)
pyplot.plot(X[:, 1], np.dot(X, theta), '-')
pyplot.legend(['Training data', 'Linear regression']);
pyplot.show()

