import numpy as np
import matplotlib.pyplot as pyplot
from computeCost import computeCost

def gradientDescentMulti(X, y, theta, alpha, num_iters):
    m = len(y)
    J_history = []

# Compute gradient descent
    for i in range(num_iters):
        predictions = X.dot(theta)  #
        errors = predictions - y
        delta = (1 / m) * (X.T.dot(errors))
        theta -= alpha * delta
        J_history.append(computeCost(X, y, theta))  

    return theta, J_history

# Load Data
data = np.loadtxt('Data/ex1data2.txt', delimiter=',')
X = data[:, 0:2]   # two features: size and number of bedrooms
y = data[:, 2]     # target variable: price
m = y.shape[0]     # number of training examples

# Run Gradient Descent
alpha = 0.1
num_iters = 300
theta = np.zeros(X.shape[1])  # match the number of features (3)
X = np.column_stack([np.ones(m), X])  # add a column of ones to X

theta, J_history = gradientDescentMulti(X, y, theta, alpha, num_iters)  

# Plot the convergence graph
pyplot.plot(np.arange(len(J_history)), J_history, lw=2)
pyplot.xlabel('Number of iterations')
pyplot.ylabel('Cost J')
pyplot.title('Convergence of Gradient Descent')
pyplot.show()

print('Theta computed from gradient descent:', theta)
