import numpy as np
from featureNormalize import featureNormalize

data = np.loadtxt('Data/ex1data2.txt', delimiter=',') # Load Data
X = data[:, 0:2]   # two features: size and number of bedrooms
y = data[:, 2]     # target variable: price
m = y.shape[0]     # number of training examples

# Normal Equations
def normalEqn(X, y):    
    theta = np.linalg.pinv(X.T.dot(X)).dot(X.T).dot(y)
    return theta

X_norm, mu, sigma = featureNormalize(X)  # Normalize Features
X = np.column_stack([np.ones(m), X_norm])  # now X has shape (47, 3)

# Predict a house price 
normalized_size = (1650 - mu[0]) / sigma[0]     # Predict the price of a 1650 sq-ft, 3 br house
normalized_bedrooms = (3 - mu[1]) / sigma[1]    # (use the same normalization as the training data)
normalized_features = np.array([1, normalized_size, normalized_bedrooms])   # add bias term

theta = normalEqn(X, y) # Calculate the parameters from the normal equation
price = normalized_features.dot(theta)  # predicted price
print(f'Predicted price of a 1650 sq-ft, 3 br house (using gradient descent): ${price:.0f}')  