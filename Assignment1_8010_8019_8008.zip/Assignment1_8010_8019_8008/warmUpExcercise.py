import numpy as np

# Warm up exercise: return a 12x12 identity matrix
def warmUpExercise():
    
    A = np.eye(5)   
    return A

print(warmUpExercise())
